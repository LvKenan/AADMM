"""
Run the LASSO scale and sparsity/noise sweeps comparing standard ADMM vs AADMM.

Fair, unified stopping metric (per JSC review): for BOTH methods we record the number
of outer iterations and CPU time to reach
        combined(k) = max( relative objective gap, primal residual ||Ax^k+y^k-b|| ) <= eps.
AADMM is limited by the objective (it attains feasibility almost immediately), ADMM by its
slower feasibility; the objective-only trajectories of the two methods coincide for this
splitting, so we also report that separately for transparency.
"""
import numpy as np, csv, json, time
from lasso_exp import run_trial

def combined_iters(gap_hist, res_hist, tols):
    comb = [max(g, r) for g, r in zip(gap_hist, res_hist)]
    hit = {t: None for t in tols}
    for k, v in enumerate(comb, start=1):
        for t in tols:
            if hit[t] is None and v <= t: hit[t] = k
    return hit, comb

def agg(vals):
    a = np.array([v for v in vals if v is not None], float)
    if a.size == 0: return (None, None)
    return float(a.mean()), float(a.std())

def run_config(m, n, sparsity, noise, seeds, tau=1.0, tols=(1e-2,1e-4,1e-6,1e-8), max_outer=4000):
    rows = {"ADMM": [], "AADMM": []}
    keep_hist = None
    for sd in seeds:
        a, g, p_ref = run_trial(m, n, sparsity, noise, tau, sd, max_outer=max_outer, n_inner=10, init_scale=1.0)
        ah, ac = combined_iters(a["gap_hist"], a["res_hist"], tols)
        gh, gc = combined_iters(g["gap_hist"], g["res_hist"], tols)
        rows["ADMM"].append(dict(comb=ah, cpu=a["cpu"], inner=a["inner"], outer=a["outer"],
                                 res=a["res"], gap=a["gap"], gobj=a["ghit"][1e-6], gres=a["rhit"][1e-6]))
        rows["AADMM"].append(dict(comb=gh, cpu=g["cpu"], inner=g["inner"], outer=g["outer"],
                                  res=g["res"], gap=g["gap"], gobj=g["ghit"][1e-6], gres=g["rhit"][1e-6]))
        if keep_hist is None:
            keep_hist = dict(p_ref=p_ref,
                             admm_res=a["res_hist"], admm_gap=a["gap_hist"], admm_comb=ac,
                             aadmm_res=g["res_hist"], aadmm_gap=g["gap_hist"], aadmm_comb=gc)
    out = {}
    for meth in ("ADMM", "AADMM"):
        R = rows[meth]
        out[meth] = dict(
            comb6=agg([r["comb"][1e-6] for r in R]),
            comb8=agg([r["comb"][1e-8] for r in R]),
            cpu=agg([r["cpu"] for r in R]),
            inner=agg([r["inner"] for r in R]),
            res=agg([r["res"] for r in R]),
            gobj=agg([r["gobj"] for r in R]),   # iters to obj-gap 1e-6 (transparency)
            gres=agg([r["gres"] for r in R]),   # iters to residual  1e-6
        )
    return out, keep_hist

def fmt(ms):
    m, s = ms
    if m is None: return "--"
    if m >= 100: return f"{m:.0f}$\\pm${s:.0f}"
    if m >= 10:  return f"{m:.0f}$\\pm${s:.0f}"
    return f"{m:.1f}$\\pm${s:.1f}"

if __name__ == "__main__":
    import sys, pickle, os
    which = sys.argv[1] if len(sys.argv) > 1 else "scale"
    seeds = [0, 1, 2]
    t_start = time.perf_counter()

    if which == "scale":
        print("=== SCALE sweep (sparsity=0.1, noise=0.05, 3 seeds) ===")
        scales = [(100,1000),(500,5000),(1000,10000)]
        scale_rows = []; hist_for_fig = None
        for (m,n) in scales:
            out, hist = run_config(m, n, 0.1, 0.05, seeds, max_outer=1500)
            if (m,n) == (500,5000): hist_for_fig = hist
            sp = out["ADMM"]["comb6"][0]/out["AADMM"]["comb6"][0] if out["AADMM"]["comb6"][0] else float('nan')
            cpu_sp = out["ADMM"]["cpu"][0]/out["AADMM"]["cpu"][0] if out["AADMM"]["cpu"][0] else float('nan')
            scale_rows.append(((m,n), out, sp, cpu_sp))
            print(f"(m,n)=({m},{n}): "
                  f"ADMM comb1e-6={fmt(out['ADMM']['comb6'])} cpu={fmt(out['ADMM']['cpu'])}s res={out['ADMM']['res'][0]:.1e} | "
                  f"AADMM comb1e-6={fmt(out['AADMM']['comb6'])} cpu={fmt(out['AADMM']['cpu'])}s res={out['AADMM']['res'][0]:.1e} | "
                  f"iter-x={sp:.1f} cpu-x={cpu_sp:.1f}", flush=True)
        np.save("results/lasso_hist_fig.npy", hist_for_fig, allow_pickle=True)
        pickle.dump(scale_rows, open("results/lasso_scale.pkl","wb"))

    elif which == "robust":
        print("=== SPARSITY/NOISE robustness at (m,n)=(500,5000), 3 seeds ===")
        sparsities = [0.05, 0.10, 0.20]; noises = [0.01, 0.10]
        robust_rows = []
        for sp_ in sparsities:
            for nz in noises:
                out, _ = run_config(500, 5000, sp_, nz, seeds, max_outer=1500)
                sp = out["ADMM"]["comb6"][0]/out["AADMM"]["comb6"][0] if out["AADMM"]["comb6"][0] else float('nan')
                robust_rows.append((sp_, nz, out, sp))
                print(f"sparsity={sp_:.2f} noise={nz:.2f}: "
                      f"ADMM comb1e-6={fmt(out['ADMM']['comb6'])} | AADMM comb1e-6={fmt(out['AADMM']['comb6'])} | "
                      f"x={sp:.1f}  (ADMM res={out['ADMM']['res'][0]:.1e}, AADMM res={out['AADMM']['res'][0]:.1e})", flush=True)
        pickle.dump(robust_rows, open("results/lasso_robust.pkl","wb"))

    print(f"\nTotal time {time.perf_counter()-t_start:.1f}s")
