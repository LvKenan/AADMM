import pickle

print("=" * 80)
print("TV Image Denoising Results")
print("=" * 80)

# ==================== 1. Size 扫描 ====================
print("\n" + "=" * 80)
print("SIZE SWEEP (noise_var=0.01, alpha=0.1)")
print("=" * 80)

with open('results/tv_size.pkl', 'rb') as f:
    data = pickle.load(f)

for sweep_type, N, nv, alpha, oA, oG in data:
    speedup = oA['it_cmb4'][0] / oG['it_cmb4'][0] if oG['it_cmb4'][0] else float('nan')
    print(f"\nSetting: {N}x{N}")
    print(f"  ADMM iters(obj):   {oA['it_obj'][0]:.0f}±{oA['it_obj'][1]:.0f}")
    print(f"  AADMM iters(obj):  {oG['it_obj'][0]:.0f}±{oG['it_obj'][1]:.0f}")
    print(f"  ADMM res@obj:      {oA['res_obj'][0]:.1e}")
    print(f"  AADMM res@obj:     {oG['res_obj'][0]:.1e}")
    print(f"  Speedup (comb.):   {speedup:.1f}x")
    print(f"  PSNR:              {oA['psnr'][0]:.2f} dB")

# ==================== 2. Noise 扫描 ====================
print("\n" + "=" * 80)
print("NOISE SWEEP (N=128, alpha=0.1)")
print("=" * 80)

with open('results/tv_noise.pkl', 'rb') as f:
    data = pickle.load(f)

for sweep_type, N, nv, alpha, oA, oG in data:
    speedup = oA['it_cmb4'][0] / oG['it_cmb4'][0] if oG['it_cmb4'][0] else float('nan')
    print(f"\nSetting: noise_var = {nv}")
    print(f"  ADMM iters(obj):   {oA['it_obj'][0]:.0f}±{oA['it_obj'][1]:.0f}")
    print(f"  AADMM iters(obj):  {oG['it_obj'][0]:.0f}±{oG['it_obj'][1]:.0f}")
    print(f"  ADMM res@obj:      {oA['res_obj'][0]:.1e}")
    print(f"  AADMM res@obj:     {oG['res_obj'][0]:.1e}")
    print(f"  Speedup (comb.):   {speedup:.1f}x")
    print(f"  PSNR:              {oA['psnr'][0]:.2f} dB")

# ==================== 3. Alpha 扫描 ====================
print("\n" + "=" * 80)
print("ALPHA SWEEP (N=128, noise_var=0.01)")
print("=" * 80)

with open('results/tv_alpha.pkl', 'rb') as f:
    data = pickle.load(f)

for sweep_type, N, nv, alpha, oA, oG in data:
    speedup = oA['it_cmb4'][0] / oG['it_cmb4'][0] if oG['it_cmb4'][0] else float('nan')
    print(f"\nSetting: alpha = {alpha}")
    print(f"  ADMM iters(obj):   {oA['it_obj'][0]:.0f}±{oA['it_obj'][1]:.0f}")
    print(f"  AADMM iters(obj):  {oG['it_obj'][0]:.0f}±{oG['it_obj'][1]:.0f}")
    print(f"  ADMM res@obj:      {oA['res_obj'][0]:.1e}")
    print(f"  AADMM res@obj:     {oG['res_obj'][0]:.1e}")
    print(f"  Speedup (comb.):   {speedup:.1f}x")
    print(f"  PSNR:              {oA['psnr'][0]:.2f} dB")

print("\n" + "=" * 80)
print("Done!")
print("=" * 80)