import numpy as np
import matplotlib.pyplot as plt

# 加载数据
data = np.load('results/lasso_hist_fig.npy', allow_pickle=True).item()

print("数据键:", data.keys())
print(f"ADMM 组合指标长度: {len(data['admm_comb'])}")
print(f"AADMM 组合指标长度: {len(data['aadmm_comb'])}")

# 创建图形
fig, axes = plt.subplots(1, 3, figsize=(15, 4))

# 图1：目标函数间隙
axes[0].semilogy(data['admm_gap'], label='ADMM', linewidth=2)
axes[0].semilogy(data['aadmm_gap'], label='AADMM', linewidth=2)
axes[0].set_xlabel('Outer Iterations')
axes[0].set_ylabel('Relative Objective Gap')
axes[0].set_title('Objective Convergence')
axes[0].grid(True, alpha=0.3)
axes[0].legend()

# 图2：残差
axes[1].semilogy(data['admm_res'], label='ADMM', linewidth=2)
axes[1].semilogy(data['aadmm_res'], label='AADMM', linewidth=2)
axes[1].set_xlabel('Outer Iterations')
axes[1].set_ylabel('Primal Residual')
axes[1].set_title('Feasibility Convergence')
axes[1].grid(True, alpha=0.3)
axes[1].legend()

# 图3：组合指标 max(gap, res)
axes[2].semilogy(data['admm_comb'], label='ADMM', linewidth=2)
axes[2].semilogy(data['aadmm_comb'], label='AADMM', linewidth=2)
axes[2].axhline(y=1e-6, color='r', linestyle='--', alpha=0.5, label='1e-6 tolerance')
axes[2].set_xlabel('Outer Iterations')
axes[2].set_ylabel('Combined Metric')
axes[2].set_title('Combined Convergence')
axes[2].grid(True, alpha=0.3)
axes[2].legend()

plt.tight_layout()
plt.savefig('new_lasso_compare.eps', dpi=300, bbox_inches='tight')
print("✅ 图片已保存为 new_lasso_compare.eps.eps")
plt.show()