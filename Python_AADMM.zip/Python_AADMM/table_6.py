import pickle

with open('results/lasso_scale.pkl', 'rb') as f:
    data = pickle.load(f)

print("=== LASSO Scale Sweep Results ===")
print()

for item in data:
    (m, n), out, speedup, cpu_speedup = item
    print(f"(m,n)=({m},{n}):")
    print(f"  ADMM iters (1e-6): {out['ADMM']['comb6'][0]:.0f}±{out['ADMM']['comb6'][1]:.0f}")
    print(f"  AADMM iters (1e-6): {out['AADMM']['comb6'][0]:.0f}±{out['AADMM']['comb6'][1]:.0f}")
    print(f"  CPU time ADMM: {out['ADMM']['cpu'][0]:.2f}±{out['ADMM']['cpu'][1]:.2f}s")
    print(f"  CPU time AADMM: {out['AADMM']['cpu'][0]:.2f}±{out['AADMM']['cpu'][1]:.2f}s")
    print(f"  Speedup (iterations): {speedup:.1f}x")
    print(f"  Speedup (CPU): {cpu_speedup:.1f}x")
    print(f"  Final residual ADMM: {out['ADMM']['res'][0]:.1e}")
    print(f"  Final residual AADMM: {out['AADMM']['res'][0]:.1e}")
    print()