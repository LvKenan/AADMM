"""
TV/ROF denoising sweeps: ADMM vs AADMM over image size, noise variance, and alpha.

Fair reporting (per JSC review). For both methods we record, from a common run:
  - it_obj : outer iters to reach relative objective gap <= 1e-4 (same target for both),
  - res@obj: primal residual ||div p+q-f|| at that point (feasibility at equal objective accuracy),
  - it_cmb : outer iters to reach combined max(obj gap, residual) <= 1e-4,
  - final residual, PSNR (vs clean), CPU, total inner (Chambolle) iterations.
"""
import numpy as np, time, sys, pickle
from tv_exp import make_image, reference_u, admm_tv, aadmm_tv

def iters_to(hist, tol):
    for k, v in enumerate(hist, 1):
        if v <= tol: return k
    return None

def res_at(gap_hist, res_hist, tol):
    for g, r in zip(gap_hist, res_hist):
        if g <= tol: return r
    return res_hist[-1]

def comb_iters(a, tol):
    for k, (g, r) in enumerate(zip(a["gap_hist"], a["res_hist"]), 1):
        if max(g, r) <= tol: return k
    return None

def metrics(a):
    return dict(it_obj=iters_to(a["gap_hist"], 1e-4),
                res_obj=res_at(a["gap_hist"], a["res_hist"], 1e-4),
                it_cmb2=comb_iters(a, 1e-2), it_cmb4=comb_iters(a, 1e-4),
                res=a["res"], psnr=a["psnr"], cpu=a["cpu"], inner=a["inner"], outer=a["outer"])

def agg(vals):
    a = np.array([v for v in vals if v is not None], float)
    return (None, None) if a.size == 0 else (float(a.mean()), float(a.std()))

def run_cfg(N, nv, alpha, seeds, ref_iters=1500, max_outer=1500, n_inner=20, keep=False):
    A = {k: [] for k in ("it_obj","res_obj","it_cmb2","it_cmb4","res","psnr","cpu","inner")}
    G = {k: [] for k in A}
    hist = None; imgs = None
    for sd in seeds:
        clean, f = make_image(N, nv, sd)
        p_ref, u_ref = reference_u(f, alpha, clean, iters=ref_iters)
        a = admm_tv(f, alpha, p_ref, clean, max_outer=max_outer, n_inner=n_inner, gtols=(1e-4,), rtols=(1e-4,))
        g = aadmm_tv(f, alpha, p_ref, clean, max_outer=max_outer, n_inner=n_inner, gtols=(1e-4,), rtols=(1e-4,))
        ma, mg = metrics(a), metrics(g)
        for k in A: A[k].append(ma[k]); G[k].append(mg[k])
        if keep and hist is None:
            # rerun longer to capture full convergence curves for the figure
            al = admm_tv(f, alpha, p_ref, clean, max_outer=2500, n_inner=n_inner, gtols=(0.0,), rtols=(0.0,))
            gl = aadmm_tv(f, alpha, p_ref, clean, max_outer=2500, n_inner=n_inner, gtols=(0.0,), rtols=(0.0,))
            hist = dict(admm_res=al["res_hist"], admm_gap=al["gap_hist"],
                        aadmm_res=gl["res_hist"], aadmm_gap=gl["gap_hist"])
            imgs = dict(clean=clean, noisy=f, admm=al["u"], aadmm=gl["u"],
                        psnr_noisy=float(20*np.log10(1.0/np.sqrt(np.mean((f-clean)**2)))),
                        psnr_admm=al["psnr"], psnr_aadmm=gl["psnr"])
    outA = {k: agg(A[k]) for k in A}; outG = {k: agg(G[k]) for k in G}
    return outA, outG, hist, imgs

def line(tag, oA, oG):
    sp = oA["it_cmb4"][0]/oG["it_cmb4"][0] if oG["it_cmb4"][0] else float('nan')
    print(f"{tag}: it_obj A={oA['it_obj'][0]:.0f} G={oG['it_obj'][0]:.0f} | "
          f"res@obj A={oA['res_obj'][0]:.1e} G={oG['res_obj'][0]:.1e} | "
          f"it_cmb4 A={oA['it_cmb4'][0]:.0f} G={oG['it_cmb4'][0]:.0f} (x{sp:.1f}) | "
          f"PSNR A={oA['psnr'][0]:.2f} G={oG['psnr'][0]:.2f} | "
          f"finalRes A={oA['res'][0]:.1e} G={oG['res'][0]:.1e} | cpu A={oA['cpu'][0]:.1f} G={oG['cpu'][0]:.1f}", flush=True)

if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "size"
    seeds = [0, 1]; t0 = time.perf_counter(); rows = []
    if which == "size":
        print("=== SIZE sweep (noise_var=0.01, alpha=0.1, 2 seeds) ===")
        for N in (64, 128, 256):
            oA, oG, hist, imgs = run_cfg(N, 0.01, 0.1, seeds, keep=(N == 128))
            line(f"N={N}x{N}", oA, oG); rows.append(("size", N, 0.01, 0.1, oA, oG))
            if N == 128:
                np.save("results/tv_hist_fig.npy", hist, allow_pickle=True)
                np.save("results/tv_imgs.npy", imgs, allow_pickle=True)
        pickle.dump(rows, open("results/tv_size.pkl", "wb"))
    elif which == "noise":
        print("=== NOISE sweep (N=128, alpha=0.1, 2 seeds) ===")
        for nv in (0.005, 0.01, 0.02):
            oA, oG, *_ = run_cfg(128, nv, 0.1, seeds)
            line(f"nv={nv}", oA, oG); rows.append(("noise", 128, nv, 0.1, oA, oG))
        pickle.dump(rows, open("results/tv_noise.pkl", "wb"))
    elif which == "alpha":
        print("=== ALPHA sweep (N=128, noise_var=0.01, 2 seeds) ===")
        for al in (0.05, 0.1, 0.2):
            oA, oG, *_ = run_cfg(128, 0.01, al, seeds)
            line(f"alpha={al}", oA, oG); rows.append(("alpha", 128, 0.01, al, oA, oG))
        pickle.dump(rows, open("results/tv_alpha.pkl", "wb"))
    print(f"\nTotal {time.perf_counter()-t0:.1f}s")
