"""
Supplementary LASSO experiments: standard ADMM vs. the paper's AADMM (AADMM-1, B=I).

Problem (paper Eq. (Lasso model) / (model-experiment)):
    min_x  tau*||x||_1 + 1/2 ||A x - b||^2
  <=> min_{x,y} tau*||x||_1 + 1/2||y||^2  s.t.  A x + y = b   (f=tau||.||_1, g=1/2||.||^2, B=I)

Both methods share the SAME inner x-subproblem solver (ISTA / proximal gradient, Eq. (FP-ADMM)),
so any difference in OUTER iterations is due to AADMM's Nesterov-type correction step.
All randomness is seeded; we report mean +/- std over several seeds.
"""
import numpy as np, time

# ---------- operators ----------
def soft(z, k):
    return np.sign(z) * np.maximum(np.abs(z) - k, 0.0)

def spectral_norm_sq(A, iters=100, seed=0):
    """ Largest eigenvalue of A^T A = ||A||_2^2 via power iteration (no A^T A formed). """
    rng = np.random.default_rng(seed)
    v = rng.standard_normal(A.shape[1]); v /= np.linalg.norm(v)
    lam = 0.0
    for _ in range(iters):
        w = A.T @ (A @ v)
        nw = np.linalg.norm(w)
        if nw == 0: return 0.0
        v = w / nw
        lam_new = v @ (A.T @ (A @ v))
        if abs(lam_new - lam) <= 1e-10 * max(1.0, lam_new): lam = lam_new; break
        lam = lam_new
    return float(lam)

# ---------- inner x-subproblem: argmin_x tau||x||_1 + 1/2||A x + c||^2  (c = y - b - lam) ----------
def inner_x(A, c, x0, tau, step, n_inner=10):
    """ ISTA (Eq. FP-ADMM): x_{j+1}=S_{step*tau}(x_j - step*A^T(A x_j + c)).
        Fixed budget of n_inner steps (identical for ADMM and AADMM). Returns x, #inner. """
    x = x0.copy(); thr = step * tau
    for j in range(n_inner):
        g = A.T @ (A @ x + c)
        x = soft(x - step * g, thr)
    return x, n_inner

# ---------- LASSO objective and reference solution (FISTA) ----------
def lasso_obj(A, b, x, tau):
    r = A @ x - b
    return tau * np.sum(np.abs(x)) + 0.5 * (r @ r)

def fista_reference(A, b, tau, L, iters=4000, tol=1e-14):
    step = 1.0 / L; thr = step * tau
    x = np.zeros(A.shape[1]); xprev = x.copy(); t = 1.0; obj_prev = np.inf
    for _ in range(iters):
        # momentum point
        tnew = (1 + np.sqrt(1 + 4 * t * t)) / 2
        w = x + ((t - 1) / tnew) * (x - xprev)
        g = A.T @ (A @ w - b)
        xprev = x
        x = soft(w - step * g, thr)
        t = tnew
        obj = lasso_obj(A, b, x, tau)
        if abs(obj_prev - obj) <= tol * max(1.0, abs(obj)): obj_prev = obj; break
        obj_prev = obj
    return x, lasso_obj(A, b, x, tau)


def _iters_to(hist, tols):
    hit = {t: None for t in tols}
    for k, v in enumerate(hist, start=1):
        for t in tols:
            if hit[t] is None and v <= t: hit[t] = k
    return hit

# ---------- standard ADMM (Eq. solution-2), penalty = 1 ----------
def admm_lasso(A, b, tau, L, p_ref, max_outer=4000, n_inner=10,
               gtols=(1e-2,1e-4,1e-6,1e-8), rtols=(1e-2,1e-4,1e-6,1e-8),
               x0=None, lam0=None, y0=None):
    m, n = A.shape; step = 1.0 / L
    x = np.zeros(n) if x0 is None else x0.copy()
    y = np.zeros(m) if y0 is None else y0.copy()
    lam = np.zeros(m) if lam0 is None else lam0.copy()
    tot_inner = 0; t0 = time.perf_counter(); res_hist=[]; gap_hist=[]
    rfloor = min(rtols)
    for k in range(1, max_outer + 1):
        c = y - b - lam
        x, ji = inner_x(A, c, x, tau, step, n_inner); tot_inner += ji
        Ax = A @ x
        y = 0.5 * (lam - (Ax - b))
        r = Ax + y - b
        lam = lam - r
        gap = abs(lasso_obj(A, b, x, tau) - p_ref) / max(1.0, abs(p_ref))
        gap_hist.append(gap); res_hist.append(float(np.linalg.norm(r)))
        if gap_hist[-1] <= min(gtols) and res_hist[-1] <= rfloor: break
    cpu = time.perf_counter() - t0
    return dict(ghit=_iters_to(gap_hist,gtols), rhit=_iters_to(res_hist,rtols),
                cpu=cpu, inner=tot_inner, outer=k, res=res_hist[-1], gap=gap_hist[-1],
                res_hist=res_hist, gap_hist=gap_hist)

# ---------- AADMM-1 (Eq. solution-1), B=I so z=y ----------
def aadmm_lasso(A, b, tau, L, p_ref, max_outer=4000, n_inner=10,
                gtols=(1e-2,1e-4,1e-6,1e-8), rtols=(1e-2,1e-4,1e-6,1e-8),
                x0=None, lam0=None, y0=None):
    m, n = A.shape; step = 1.0 / L
    x = np.zeros(n) if x0 is None else x0.copy()
    y = np.zeros(m) if y0 is None else y0.copy()
    lam = np.zeros(m) if lam0 is None else lam0.copy()
    yt_prev = y.copy(); lamt_prev = lam.copy(); t = 1.0
    tot_inner = 0; t0 = time.perf_counter(); res_hist=[]; gap_hist=[]
    rfloor = min(rtols)
    for k in range(1, max_outer + 1):
        c = y - b - lam
        xt, ji = inner_x(A, c, x, tau, step, n_inner); tot_inner += ji
        Axt = A @ xt
        lamt = lam - (Axt + y - b)
        yt = lamt.copy()
        tnew = (1 + np.sqrt(1 + 4 * t * t)) / 2
        x = xt
        y_new = ((tnew - 1)/(2*tnew))*yt - ((t - 1)/(2*tnew))*yt_prev + (t/(2*tnew))*(lamt - lam + y)
        lam_new = lamt + ((t - 1)/tnew)*(lamt - lamt_prev) + (t/tnew)*(lamt - lam + y - yt) - y_new
        r = Axt + yt - b
        gap = abs(lasso_obj(A, b, xt, tau) - p_ref) / max(1.0, abs(p_ref))
        gap_hist.append(gap); res_hist.append(float(np.linalg.norm(r)))
        yt_prev = yt; lamt_prev = lamt; y = y_new; lam = lam_new; t = tnew
        if gap_hist[-1] <= min(gtols) and res_hist[-1] <= rfloor: break
    cpu = time.perf_counter() - t0
    return dict(ghit=_iters_to(gap_hist,gtols), rhit=_iters_to(res_hist,rtols),
                cpu=cpu, inner=tot_inner, outer=k, res=res_hist[-1], gap=gap_hist[-1],
                res_hist=res_hist, gap_hist=gap_hist)

# ---------- data ----------
def make_lasso(m, n, sparsity, noise, tau, seed):
    rng = np.random.default_rng(seed)
    A = rng.standard_normal((m, n)) / np.sqrt(m)      # columns ~unit scale
    k = max(1, int(round(sparsity * n)))
    x_true = np.zeros(n); idx = rng.choice(n, k, replace=False)
    x_true[idx] = rng.standard_normal(k)
    b = A @ x_true + noise * rng.standard_normal(m)
    return A, b

# ---------- one trial ----------
def run_trial(m, n, sparsity, noise, tau, seed, max_outer=4000, n_inner=10, init_scale=1.0):
    A, b = make_lasso(m, n, sparsity, noise, tau, seed)
    L = spectral_norm_sq(A, seed=seed)
    x_ref, p_ref = fista_reference(A, b, tau, L)
    rng = np.random.default_rng(10000 + seed)              # common start for BOTH methods
    x0 = init_scale * rng.standard_normal(n)
    y0 = init_scale * rng.standard_normal(m)
    lam0 = init_scale * rng.standard_normal(m)
    a = admm_lasso(A, b, tau, L, p_ref, max_outer=max_outer, n_inner=n_inner, x0=x0, y0=y0, lam0=lam0)
    g = aadmm_lasso(A, b, tau, L, p_ref, max_outer=max_outer, n_inner=n_inner, x0=x0, y0=y0, lam0=lam0)
    return a, g, p_ref

if __name__ == "__main__":
    for (m,n) in [(100,1000),(500,5000)]:
        a,g,p = run_trial(m,n,0.1,0.05,1.0,seed=0,max_outer=4000)
        print("(m,n)=(%d,%d) p_ref=%.4e"%(m,n,p))
        print("  ADMM  gap-iters",a["ghit"]," res-iters",a["rhit"])
        print("        outer=%d cpu=%.2fs inner=%d res=%.2e gap=%.2e"%(a["outer"],a["cpu"],a["inner"],a["res"],a["gap"]))
        print("  AADMM gap-iters",g["ghit"]," res-iters",g["rhit"])
        print("        outer=%d cpu=%.2fs inner=%d res=%.2e gap=%.2e"%(g["outer"],g["cpu"],g["inner"],g["res"],g["gap"]))
