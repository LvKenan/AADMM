"""
Supplementary TV (ROF) image-denoising experiments: standard ADMM vs AADMM.

Primal ROF (paper Eq. DM-1):  min_u 1/2||u-f||^2 + alpha ||grad u||_1
Dual (paper Eq. DM):          -min_{q, ||p||_inf<=alpha} 1/2||q||^2  s.t.  div p + q = f
(g=1/2||q||^2 strongly convex, B=I; multiplier u = restored image.)

Both ADMM (Eq. Solution-2) and AADMM (Eq. Solution-1) share the SAME p-subproblem solved by a
projected-gradient (Chambolle) inner loop, so any outer-iteration difference is due to the
correction step. All randomness seeded.
"""
import numpy as np, time

# ---------- discrete gradient / divergence (forward diff, Neumann BC); div = -grad^* ----------
def grad(u):
    gx = np.zeros_like(u); gy = np.zeros_like(u)
    gx[:, :-1] = u[:, 1:] - u[:, :-1]
    gy[:-1, :] = u[1:, :] - u[:-1, :]
    return gx, gy

def div(px, py):
    dx = np.zeros_like(px); dy = np.zeros_like(py)
    dx[:, 0] = px[:, 0]; dx[:, 1:-1] = px[:, 1:-1] - px[:, :-2]; dx[:, -1] = -px[:, -2]
    dy[0, :] = py[0, :]; dy[1:-1, :] = py[1:-1, :] - py[:-2, :]; dy[-1, :] = -py[-2, :]
    return dx + dy

def proj_ball(px, py, alpha):
    nrm = np.sqrt(px*px + py*py); fac = np.maximum(1.0, nrm/alpha)
    return px/fac, py/fac

# p-subproblem: argmin_{||p||_inf<=alpha} 1/2|| div p - gt ||^2  via projected gradient (Chambolle)
def chambolle_p(gt, alpha, px, py, n_inner=20, tau=1.0/8):
    for _ in range(n_inner):
        r = div(px, py) - gt
        rx, ry = grad(r)                 # grad(div p - gt);  step uses +tau*grad(div p - gt)
        px = px + tau*rx; py = py + tau*ry
        px, py = proj_ball(px, py, alpha)
    return px, py

def rof_obj(u, f, alpha):
    gx, gy = grad(u)
    return 0.5*np.sum((u-f)**2) + alpha*np.sum(np.sqrt(gx*gx + gy*gy))

def psnr(u, clean, peak=1.0):
    mse = np.mean((u-clean)**2)
    return 99.0 if mse <= 1e-20 else 10*np.log10(peak*peak/mse)

# ---------- standard ADMM (Eq. Solution-2) ----------
def admm_tv(f, alpha, p_ref, clean, max_outer=2000, n_inner=20,
            gtols=(1e-2,1e-4,1e-6), rtols=(1e-2,1e-4,1e-6)):
    u = np.zeros_like(f); q = np.zeros_like(f); px = np.zeros_like(f); py = np.zeros_like(f)
    res_hist=[]; gap_hist=[]; du_hist=[]; tot_inner=0; t0=time.perf_counter()
    for k in range(1, max_outer+1):
        gt = f + u - q
        px, py = chambolle_p(gt, alpha, px, py, n_inner); tot_inner += n_inner
        dvp = div(px, py)
        q = 0.5*(u - dvp + f)
        r = dvp + q - f
        u_new = u - r
        du = np.linalg.norm(u_new - u); u = u_new
        res_hist.append(float(np.linalg.norm(r)))
        gap_hist.append(abs(rof_obj(u, f, alpha) - p_ref)/max(1.0, abs(p_ref)))
        du_hist.append(float(du))
        if gap_hist[-1] <= min(gtols) and res_hist[-1] <= min(rtols): break
    cpu=time.perf_counter()-t0
    return dict(res_hist=res_hist, gap_hist=gap_hist, du_hist=du_hist, cpu=cpu, inner=tot_inner,
                outer=k, res=res_hist[-1], gap=gap_hist[-1], u=u, psnr=psnr(u, clean))

# ---------- AADMM (Eq. Solution-1), B=I ----------
def aadmm_tv(f, alpha, p_ref, clean, max_outer=2000, n_inner=20,
             gtols=(1e-2,1e-4,1e-6), rtols=(1e-2,1e-4,1e-6)):
    u = np.zeros_like(f); q = np.zeros_like(f); px = np.zeros_like(f); py = np.zeros_like(f)
    qt_prev = q.copy(); ut_prev = u.copy(); t = 1.0
    res_hist=[]; gap_hist=[]; du_hist=[]; tot_inner=0; t0=time.perf_counter()
    u_prev_corr = u.copy()
    for k in range(1, max_outer+1):
        gt = f + u - q
        px, py = chambolle_p(gt, alpha, px, py, n_inner); tot_inner += n_inner
        dvp = div(px, py)
        ut = u - (dvp + q - f)        # u-predictor (restored-image predictor)
        qt = ut.copy()                # g=1/2||.||^2, B=I  => q-predictor = u-predictor
        tnew = (1+np.sqrt(1+4*t*t))/2
        q_new = ((tnew-1)/(2*tnew))*qt - ((t-1)/(2*tnew))*qt_prev + (t/(2*tnew))*(ut - u + q)
        u_new = ut + ((t-1)/tnew)*(ut - ut_prev) + (t/tnew)*(ut - u + q - qt) - q_new
        r = dvp + qt - f                                   # predictor residual
        res_hist.append(float(np.linalg.norm(r)))
        gap_hist.append(abs(rof_obj(ut, f, alpha) - p_ref)/max(1.0, abs(p_ref)))
        du_hist.append(float(np.linalg.norm(ut - u_prev_corr))); u_prev_corr = ut
        qt_prev = qt; ut_prev = ut; q = q_new; u = u_new; t = tnew
        if gap_hist[-1] <= min(gtols) and res_hist[-1] <= min(rtols): break
    cpu=time.perf_counter()-t0
    return dict(res_hist=res_hist, gap_hist=gap_hist, du_hist=du_hist, cpu=cpu, inner=tot_inner,
                outer=k, res=res_hist[-1], gap=gap_hist[-1], u=ut, psnr=psnr(ut, clean))

# ---------- synthetic piecewise-constant phantom (ideal for TV) ----------
def phantom(N, seed=0):
    rng = np.random.default_rng(seed)
    img = np.full((N, N), 0.15)
    # a few constant-intensity rectangles and disks
    for _ in range(5):
        h = rng.integers(N//6, N//2); w = rng.integers(N//6, N//2)
        i = rng.integers(0, N-h); j = rng.integers(0, N-w)
        img[i:i+h, j:j+w] = rng.uniform(0.3, 0.95)
    yy, xx = np.mgrid[0:N, 0:N]
    for _ in range(3):
        cy, cx = rng.integers(N//5, 4*N//5, size=2); rad = rng.integers(N//10, N//4)
        img[(yy-cy)**2 + (xx-cx)**2 <= rad*rad] = rng.uniform(0.2, 0.9)
    return np.clip(img, 0, 1)

def make_image(N, noise_var, seed):
    clean = phantom(N, seed)
    rng = np.random.default_rng(1000+seed)
    f = clean + np.sqrt(noise_var)*rng.standard_normal((N, N))
    return clean, f

def reference_u(f, alpha, clean, iters=4000):
    # high-accuracy reference via a long AADMM run
    r = aadmm_tv(f, alpha, p_ref=0.0, clean=clean, max_outer=iters,
                 gtols=(0.0,), rtols=(0.0,))   # never stop early
    return rof_obj(r["u"], f, alpha), r["u"]

if __name__ == "__main__":
    # adjoint test: <grad u, p> == -<u, div p>
    rng=np.random.default_rng(0); u=rng.standard_normal((16,16)); px=rng.standard_normal((16,16)); py=rng.standard_normal((16,16))
    gx,gy=grad(u); lhs=np.sum(gx*px+gy*py); rhs=-np.sum(u*div(px,py))
    print("adjoint test |lhs-rhs|=%.2e (should be ~0)"%abs(lhs-rhs))
    # quick denoising run
    clean,f=make_image(128,0.01,0); alpha=0.1
    p_ref,_=reference_u(f,alpha,clean,iters=3000)
    a=admm_tv(f,alpha,p_ref,clean,max_outer=2000); g=aadmm_tv(f,alpha,p_ref,clean,max_outer=2000)
    print("p_ref=%.4e  noisy PSNR=%.2f dB"%(p_ref, psnr(f,clean)))
    print("ADMM  outer=%d cpu=%.2fs inner=%d res=%.1e gap=%.1e PSNR=%.2f"%(a["outer"],a["cpu"],a["inner"],a["res"],a["gap"],a["psnr"]))
    print("AADMM outer=%d cpu=%.2fs inner=%d res=%.1e gap=%.1e PSNR=%.2f"%(g["outer"],g["cpu"],g["inner"],g["res"],g["gap"],g["psnr"]))
