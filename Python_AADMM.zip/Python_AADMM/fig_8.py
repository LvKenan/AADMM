import numpy as np
import matplotlib.pyplot as plt
import os

def plot_tv_convergence():
    """
    生成 TV 去噪收敛曲线图（Figure fig:tv-conv）
    """
    # 检查数据文件是否存在
    if not os.path.exists('results/tv_hist_fig.npy'):
        print("Error: results/tv_hist_fig.npy not found.")
        print("Please run: python run_tv_sweeps.py size first.")
        return None
    
    # 读取数据
    hist = np.load('results/tv_hist_fig.npy', allow_pickle=True).item()
    
    # 提取迭代次数
    iters = range(1, len(hist['admm_res']) + 1)
    
    # 计算 combined metric
    admm_comb = [max(g, r) for g, r in zip(hist['admm_gap'], hist['admm_res'])]
    aadmm_comb = [max(g, r) for g, r in zip(hist['aadmm_gap'], hist['aadmm_res'])]
    
    # 创建图形
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))
    
    # ---- 左图：Primal residual ----
    ax1.semilogy(iters, hist['admm_res'], 'b-', label='ADMM', linewidth=2)
    ax1.semilogy(iters, hist['aadmm_res'], 'r-', label='AADMM', linewidth=2)
    ax1.set_xlabel('Outer iteration', fontsize=12)
    ax1.set_ylabel(r'Primal residual $\|\mathrm{div}\,p^k+q^k-f\|$', fontsize=12)
    ax1.legend(fontsize=11)
    ax1.grid(True, alpha=0.3)
    ax1.set_title('(a) Primal residual', fontsize=12)
    
    # ---- 右图：Combined criterion ----
    ax2.semilogy(iters, admm_comb, 'b-', label='ADMM', linewidth=2)
    ax2.semilogy(iters, aadmm_comb, 'r-', label='AADMM', linewidth=2)
    ax2.axhline(y=1e-4, color='k', linestyle='--', linewidth=1, label=r'$10^{-4}$ tolerance')
    ax2.set_xlabel('Outer iteration', fontsize=12)
    ax2.set_ylabel(r'Combined metric $\max(\text{gap}, \text{residual})$', fontsize=12)
    ax2.legend(fontsize=11)
    ax2.grid(True, alpha=0.3)
    ax2.set_title('(b) Combined criterion', fontsize=12)
    
    # 调整布局并保存
    plt.tight_layout()
    
    # 同时保存为 PNG（预览用）
    plt.savefig('new_tv_compare.eps', dpi=300, bbox_inches='tight')
    print("Figure saved to: new_tv_compare.eps")
    
    plt.show()
    
    # 打印一些统计信息
    print("\n=== Statistics ===")
    print(f"Total iterations: {len(hist['admm_res'])}")
    print(f"ADMM final residual: {hist['admm_res'][-1]:.2e}")
    print(f"AADMM final residual: {hist['aadmm_res'][-1]:.2e}")
    print(f"ADMM final combined: {admm_comb[-1]:.2e}")
    print(f"AADMM final combined: {aadmm_comb[-1]:.2e}")
    
    # 计算达到 1e-4 的迭代次数
    for i, v in enumerate(aadmm_comb, 1):
        if v <= 1e-4:
            print(f"AADMM reaches 1e-4 at iteration: {i}")
            break
    
    return fig

if __name__ == "__main__":
    plot_tv_convergence()