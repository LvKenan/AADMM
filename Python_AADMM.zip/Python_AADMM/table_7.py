import pickle

with open('results/lasso_robust.pkl', 'rb') as f:
    data = pickle.load(f)

for sp, nz, out, speedup in data:
    print(f"sparsity={sp}, noise={nz}:")
    print(f"  ADMM iters: {out['ADMM']['comb6'][0]:.0f}±{out['ADMM']['comb6'][1]:.0f}")
    print(f"  AADMM iters: {out['AADMM']['comb6'][0]:.0f}±{out['AADMM']['comb6'][1]:.0f}")
    print(f"  Speedup: {speedup:.1f}x")
    print(f"  AADMM residual: {out['AADMM']['res'][0]:.1e}")
    print()