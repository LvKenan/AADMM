import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

imgs = np.load('results/tv_imgs.npy', allow_pickle=True).item()

# 定义放大区域（例如图像中心区域）
N = imgs['clean'].shape[0]
crop_size = 40
start = (N - crop_size) // 2

fig, axes = plt.subplots(2, 4, figsize=(16, 8))

# 第一行：全图
images = [
    ('Clean', imgs['clean'], None),
    ('Noisy', imgs['noisy'], imgs['psnr_noisy']),
    ('ADMM', imgs['admm'], imgs['psnr_admm']),
    ('AADMM', imgs['aadmm'], imgs['psnr_aadmm'])
]

for idx, (title, img, psnr) in enumerate(images):
    axes[0, idx].imshow(img, cmap='gray', vmin=0, vmax=1)
    if psnr is not None:
        axes[0, idx].set_title(f'{title}\nPSNR: {psnr:.2f} dB', fontsize=11)
    else:
        axes[0, idx].set_title(title, fontsize=11)
    axes[0, idx].axis('off')
    # 标记放大区域
    rect = Rectangle((start, start), crop_size, crop_size, 
                     linewidth=2, edgecolor='red', facecolor='none')
    axes[0, idx].add_patch(rect)

# 第二行：局部放大
crop_images = [
    ('Clean (crop)', imgs['clean'][start:start+crop_size, start:start+crop_size], None),
    ('Noisy (crop)', imgs['noisy'][start:start+crop_size, start:start+crop_size], None),
    ('ADMM (crop)', imgs['admm'][start:start+crop_size, start:start+crop_size], None),
    ('AADMM (crop)', imgs['aadmm'][start:start+crop_size, start:start+crop_size], None)
]

for idx, (title, img, psnr) in enumerate(crop_images):
    axes[1, idx].imshow(img, cmap='gray', vmin=0, vmax=1)
    axes[1, idx].set_title(title, fontsize=11)
    axes[1, idx].axis('off')

plt.tight_layout()
plt.savefig('new_tv_show.eps', dpi=300, bbox_inches='tight')
plt.show()