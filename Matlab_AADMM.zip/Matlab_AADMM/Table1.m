clear all;close;clc;clc
% erriter= Lk+1 - Lk

rng('shuffle');


% initial value
m=5;
n=100;
beta=1;
t=1;
tau=1;
sigma=tau/1000;
epsilon=1e-12;
NumIter=5e4;

% random initial value
A=randn(m,n,'double');
AT=A';
b=zeros(m,1);


% x,y,lambda initial value
tx=10*rand(n,1);
x=tx;
ty=10*rand(m,1);
y=ty; %ty: \tilde{y}
tlambda=10*rand(m,1);
lambda=tlambda; %tlambda: \tilde{\lambda}


% keep same initial value for other algorithm
xx=tx;
yy=ty;
llambda=tlambda;

% AADMM
% record change x,y,lambda
AH=[];
AV=[];
AVx=[];
AVy=[];
AVlambda=[];
AEX=[];
Aresidual=[];  % 记录残差 ||A*tx+ty-b||_2

tic
for i=1:NumIter
    
    % keep x,y,lambda
    X=x;
    Y=y;
    Lambda=lambda;
    
    % step1: update tx
    for j=1:1e3
        xf=x;
        P=beta/tau*AT*(A*xf+y-b-lambda/beta);
        x=max(xf-sigma*P-sigma,0)-max(-xf+sigma*P-sigma,0);
        ex=sqrt(sum((x-xf).*(x-xf)));
        if ex<1e-4
            break;
        end
    end
    tx=x;
    
    % record ex
    AEX(i)=ex;
    
    %step2: update tlambda
    Tlambda=tlambda; % keep tlambda
    tlambda=lambda-beta*(A*tx+y-b);
    
    %step3: update ty
    Ty=ty; %keep ty
    ty=tlambda;
    
    %step4: update t
    T=t; %keep t
    t=(1+sqrt(1+4*t^2))/2;
    
    %step5: update x
    x=tx;
    
    %step6: update y
    y=(t-1)/(2*t)*ty-(T-1)/(2*t)*Ty+T/(2*t)*((tlambda-lambda)+...
        (1-beta)*ty+beta*y);
    
    %step7: update lambda
    lambda=(t-1)/(2*t)*(2*tlambda-beta*ty)+...
        (T-1)/(2*t)*(beta*Ty-2*Tlambda)+...
        T/(2*t)*((beta-2)*lambda+(4-beta)*tlambda...
        +(beta^2-3*beta)*ty+(2*beta-beta^2)*Y);
    
    % 记录残差 ||A*tx+ty-b||_2
    residual = norm(A*tx + ty - b, 2);
    Aresidual(i) = residual;
    
    % record L value (i)
    AH(i)=(i);
    Afvalue=abs(tau*sum(abs(tx))+1/2*sum(ty.*ty)-sum(tlambda.*(A*tx+ty-b)));
    AV(i)=log(Afvalue);
 
    if Afvalue<epsilon
        break;
    end
    
end
toc
timet = toc

% record convergence point
APx=tx;
APy=ty;
APlambda=tlambda;

msg = sprintf(['The iteration of AADMM = %u. \n'], i);

% difference between AADMM and solution
DAA_x=sqrt(sum((APx).*(APx)))/n;
DAA_y=sqrt(sum((APy).*(APy)))/m;
DAA_lambda=sqrt(sum((APlambda).*(APlambda)))/m;
res_AADMM=sqrt(sum((A*APx+APy).*(A*APx+APy)));


% ADMM
% keep same initial value as AADMM
x=xx;
y=yy;
lambda=llambda;

% record change x,y,lambda
H=[];
V=[];
Vx=[];
Vy=[];
Vlambda=[];
EX=[];
residual=[];  % 记录残差 ||A*x+y-b||_2

tic
for i=1:NumIter
    
    % keep x,y,lambda
    X=x;
    Y=y;
    Lambda=lambda;
    
    % update x
    for j=1:1e3
        xf=x;
        P=beta/tau*AT*(A*xf+y-b-lambda/beta);
        x=max(xf-sigma*P-sigma,0)-max(-xf+sigma*P-sigma,0);
        ex=sqrt(sum((x-xf).*(x-xf)));
        if ex<1e-4
            break;
        end
    end
    
    % record ex
    EX(i)=ex;
    
    % update y
    y=(lambda-beta*(A*x-b))/(1+beta);
    % update lambda
    lambda=lambda-beta*(A*x+y-b);
    
    
    % record L value (i)
    H(i)=(i);
    f1value=tau*sum(abs(x))+1/2*sum(y.*y);
    f2value=sqrt(sum((A*x+y-b).*(A*x+y-b)));
    fvalue=max(f1value,f2value);
    V(i)=log(fvalue);
    
    
    if fvalue<epsilon
        break;
    end
    
end
toc
timet = toc

% record iteration point (i+1)
Px=x;
Py=y;
Plambda=lambda;

Msg = sprintf(['The iteration of ADMM = %u. \n'], i);


% difference between ADMM and solution
DA_x=sqrt(sum((Px).*(Px)))/n;
DA_y=sqrt(sum((Py).*(Py)))/m;
DA_lambda=sqrt(sum((Plambda).*(Plambda)))/m;

% residual ADMM
res_ADMM=sqrt(sum((A*Px+Py).*(A*Px+Py)));

% C
C=1/beta*sum((llambda+beta*yy).*(llambda+beta*yy))...
    +1/(2-beta)*sum((llambda+(beta-4)*yy)...
    .*(llambda+(beta-4)*yy));


msg1 = sprintf(['DAA_x= %u. \n'], DAA_x);
msg2 = sprintf(['DAA_y= %u. \n'], DAA_y);
msg3 = sprintf(['DAA_lambda= %u. \n'], DAA_lambda);
msg4 = sprintf(['DA_x= %u. \n'], DA_x);
msg5 = sprintf(['DA_y= %u. \n'], DA_y);
msg6 = sprintf(['DA_lambda= %u. \n'], DA_lambda);
msg7 = sprintf(['C= %u. \n'], C);
msg8 = sprintf(['Error_AADMM= %u. \n'], Afvalue);
msg9 = sprintf(['Error_ADMM= %u. \n'], fvalue);
msg10 = sprintf(['residual_AADMM= %u. \n'], res_AADMM);
msg11 = sprintf(['residual_ADMM= %u. \n'], res_ADMM);

% about AADMM
disp(msg);
disp(msg1);
disp(msg2);
disp(msg3);
disp(msg7);
disp(msg8);
disp(msg10);

% about ADMM
disp(Msg);
disp(msg4);
disp(msg5);
disp(msg6);
disp(msg9);
disp(msg11);


